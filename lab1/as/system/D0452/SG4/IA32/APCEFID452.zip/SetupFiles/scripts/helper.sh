#!/bin/bash
# installARemb.sh - A menu driven shell script to install ARemb on an APC.
# Author: Peter Maier
# Date: 12/Jun/2016

WINDOWS_TAG="Windows"
LINUX_TAG="Linux"
AR_SYSTEM_DIR="/SYSTEM"
GRUB_DIR=$AR_SYSTEM_DIR"/GRUB"
RTH_DIR=$AR_SYSTEM_DIR"/RTH"

mountedDirIndex=1

# Purpose: Display pause prompt
# $1-> Message (optional)
function pause(){
	local message="$@"
	[ -z $message ] && message="Press [Enter] key to continue, [ESC] to exit..."
	read -p "$message" readEnterKey
	if [ "$readEnterKey" = $'\e' ]; then		# ESC
		exit 0;
	fi
}

function DEBUG_MESSAGE() {
	if [ -n "$DEBUG_MODE" ]; then
		local noAction=
		if [ -n "$NO_ACTION" ]; then
			noAction="NO_ACTION: "
		fi
		echo "$noAction${BASH_SOURCE[1]}:${BASH_LINENO[0]}: $@"
		if [ -n "$STEPPING_MODE" ]; then
			pause
		fi
	fi
	LAST_DEBUG_MESSAGE="$@"
}

function printError() {
	echo "${BASH_SOURCE[1]}:${BASH_LINENO[0]}: $@"
	echo "last debug msg: $LAST_DEBUG_MESSAGE"
	exit 1
}

function mountPartition() {
	local __mountedDir=$1
	local devicePartNr=$2

	local mountedDir="/mnt/part"

	if [ -z "$devicePartNr" ]; then
		printError "no device and partition number given. mountPartition ($__mountedDir, $devicePartNr)"
	fi

	mountedDir=$mountedDir$mountedDirIndex
	let mountedDirIndex=$mountedDirIndex+1

	DEBUG_MESSAGE "mkdir -p $mountedDir"
	mkdir -p $mountedDir

	DEBUG_MESSAGE "mount $devicePartNr $mountedDir"
	mount $devicePartNr $mountedDir
	local retv=$?
	if [ "$retv" = "0" ]; then
		local isNtfs=$(mount | grep $devicePartNr | grep "type ntfs")
		if [ -n "$isNtfs" ]; then		#remount
			DEBUG_MESSAGE "umount $mountedDir"
			umount $mountedDir
			DEBUG_MESSAGE "mount -t ntfs-3g $devicePartNr $mountedDir"
			mount -t ntfs-3g $devicePartNr $mountedDir
			retv=$?
		fi
	fi

	eval $__mountedDir=$mountedDir
	return $retv
}

function umountDir() {
	local dir=$1

	DEBUG_MESSAGE "umount $dir"
	if [ -z "$dir" ]; then
		printError "no dir given. umountDir ($dir)"
	fi

	umount $dir
	rmdir $dir
}

function _getDiskNumberOfDevice(){
	local __num=$1
	local dev=$2

	DEBUG_MESSAGE "getting disk number for device $dev"

	if [ -z "$dev" ]; then
		printError "no device given. _getDiskNumberOfDevice($__num, $dev)"
	fi

	local letter=${dev:7}
	local num="0"
	if [ "$letter" = "a" ]; then
		num="0"
	elif [ "$letter" = "b" ]; then
		num="1"
	elif [ "$letter" = "c" ]; then
		num="2"
	elif [ "$letter" = "d" ]; then
		num="3"
	fi
	eval "${__num}='${num}'"	
}

if [ -n "$DEBUG_MODE" ]; then
	echo "debug ($DEBUG_MODE_PARAM):                on"
	if [ -n "$STEPPING_MODE" ]; then 
		singleSteps="on"
	else
		singleSteps="off"
	fi
	if [ -n "$NO_ACTION" ]; then 
		noAction="on"
	else
		noAction="off"
	fi
	if [ -n "$CALL_LOCAL" ]; then 
		callLocal="on"
	else
		callLocal="off"
	fi
	echo "single steps ($STEPPING_MODE_PARAM): $singleSteps"
	echo "no actions ($NO_ACTION_PARAM):       $noAction"
	echo "local call ($CALL_LOCAL_PARAM):      $callLocal"
	pause
fi
